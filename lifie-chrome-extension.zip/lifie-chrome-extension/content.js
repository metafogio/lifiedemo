// Content script that runs on every page
(async function() {
  // Get settings from storage
  const result = await chrome.storage.sync.get(['enabled', 'scriptTag']);
  
  // Only inject if enabled and scriptTag is set
  if (!result.enabled || !result.scriptTag) {
    return;
  }
  
  // Check if script is already injected
  if (document.querySelector('script[src*="lifiechat.js"]')) {
    console.log('Lifie chat widget already injected');
    return;
  }
  
  // Inject the script that runs in the page's main world (bypasses CSP)
  const scriptTag = document.createElement('script');
  scriptTag.src = chrome.runtime.getURL('injected.js');
  scriptTag.onload = function() {
    console.log('[Lifie Extension] Injected script loaded, dispatching config...');
    
    // Small delay to ensure listener is ready (injected script executes synchronously)
    setTimeout(() => {
      // Send configuration to the injected script via custom event
      window.dispatchEvent(new CustomEvent('lifieExtensionConfig', {
        detail: {
          scriptTag: result.scriptTag
        }
      }));
      
      console.log('[Lifie Extension] Config dispatched');
      
      // Remove the script tag after it's loaded
      scriptTag.remove();
    }, 50);
  };
  
  scriptTag.onerror = function() {
    console.error('[Lifie Extension] Failed to load injected script');
  };
  
  (document.head || document.documentElement).appendChild(scriptTag);
  console.log('[Lifie Extension] Loading injected script...');
})();


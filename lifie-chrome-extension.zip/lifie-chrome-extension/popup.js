// DOM elements
const enableToggle = document.getElementById('enableToggle');
const scriptTagInput = document.getElementById('scriptTag');
const saveBtn = document.getElementById('saveBtn');
const messageDiv = document.getElementById('message');
const statusBadge = document.getElementById('statusBadge');
const statusText = document.getElementById('statusText');

// Load saved settings when popup opens
document.addEventListener('DOMContentLoaded', async () => {
  const result = await chrome.storage.sync.get(['enabled', 'scriptTag']);
  
  enableToggle.checked = result.enabled || false;
  scriptTagInput.value = result.scriptTag || '';
  
  updateStatus(result.enabled);
});

// Toggle enable/disable
enableToggle.addEventListener('change', async () => {
  const enabled = enableToggle.checked;
  await chrome.storage.sync.set({ enabled });
  updateStatus(enabled);
  showMessage('Widget ' + (enabled ? 'enabled' : 'disabled'), 'success');
  
  // Reload active tab to apply changes
  reloadActiveTab();
});

// Save script tag
saveBtn.addEventListener('click', async () => {
  const scriptTag = scriptTagInput.value.trim();
  
  if (!scriptTag) {
    showMessage('Please paste your script tag', 'error');
    return;
  }
  
  // Basic validation to check if it looks like a script tag
  if (!scriptTag.includes('<script') || !scriptTag.includes('</script>')) {
    showMessage('Invalid script tag format. Please paste the complete script tag.', 'error');
    return;
  }
  
  await chrome.storage.sync.set({ scriptTag });
  showMessage('Configuration saved successfully!', 'success');
  
  // Reload active tab to apply changes
  reloadActiveTab();
});

// Update status indicator
function updateStatus(enabled) {
  if (enabled) {
    statusBadge.classList.remove('inactive');
    statusText.textContent = 'Widget is active';
  } else {
    statusBadge.classList.add('inactive');
    statusText.textContent = 'Widget is disabled';
  }
}

// Show message
function showMessage(text, type) {
  messageDiv.textContent = text;
  messageDiv.className = 'message ' + type;
  messageDiv.style.display = 'block';
  
  setTimeout(() => {
    messageDiv.style.display = 'none';
  }, 3000);
}

// Reload active tab
async function reloadActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) {
    chrome.tabs.reload(tab.id);
  }
}


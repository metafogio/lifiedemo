// This script runs in the page's main world and has access to the page's JavaScript context
// It receives the script tag content via a custom event

(function() {
  console.log('[Lifie Extension] Injected script loaded, setting up listener...');
  
  window.addEventListener('lifieExtensionConfig', function(event) {
    console.log('[Lifie Extension] Received config event');
    const config = event.detail;
    
    if (!config || !config.scriptTag) {
      console.error('[Lifie Extension] No script tag in config');
      return;
    }
    
    console.log('[Lifie Extension] Script tag received, length:', config.scriptTag.length);
    
    // Extract the JavaScript code from the script tag
    const scriptContent = config.scriptTag.replace(/<script[^>]*>/i, '').replace(/<\/script>/i, '').trim();
    
    console.log('[Lifie Extension] Extracted script content, length:', scriptContent.length);
    
    try {
      // Execute the script content in the page's context
      const scriptElement = document.createElement('script');
      scriptElement.textContent = scriptContent;
      (document.head || document.documentElement).appendChild(scriptElement);
      console.log('[Lifie Extension] Lifie chat widget script injected successfully');
    } catch (error) {
      console.error('[Lifie Extension] Failed to inject Lifie chat widget script:', error);
    }
  });
  
  console.log('[Lifie Extension] Listener ready');
})();


